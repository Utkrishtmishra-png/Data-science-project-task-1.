# Week 4 Summary: Data Visualization with Matplotlib and Seaborn

## Concepts Learned

**Matplotlib — Basic Plots**
- **Line plots** for trends over time (`plt.plot`)
- **Bar charts** for comparing totals across categories (`plt.bar`)
- **Histograms** for showing the distribution/spread of a numeric
  variable (`plt.hist`)
- **Scatter plots** for showing the relationship between two numeric
  variables, with color used to encode a third categorical variable
- `plt.subplots()` builds a grid of panels in one figure — the basis
  for a combined "dashboard" view

**Seaborn — Advanced Plots**
- **Heatmaps** (`sns.heatmap`) visualize a correlation matrix at a
  glance, with color intensity showing strength/direction of
  relationships
- **Pairplots** (`sns.pairplot`) show every pairwise relationship
  between numeric columns at once, split by a categorical `hue`
- **Boxplots** (`sns.boxplot`) compare distributions (median, quartiles,
  outliers) across groups
- Seaborn builds on Matplotlib but adds better default styling and
  statistical plot types with less code

## Hands-On Work
`visualization_script.py` generates 7 plots from the client's cleaned
`retail_sales_data.csv`, saved to `plots/`:
1. Line — total daily revenue over time
2. Bar — total revenue by category
3. Histogram — distribution of units sold
4. Scatter — temperature vs. units sold, by category
5. Seaborn heatmap — correlation between units sold, revenue, temperature
6. Seaborn pairplot — pairwise relationships by category
7. Seaborn boxplot — revenue distribution by store

**Key visual finding:** the heatmap and pairplot both confirm what Week
3's correlation analysis found numerically — Ice Cream sales visibly
track temperature much more closely than other categories.

## Client Project
`client_project_dashboard.py` combines four panels into a single
`dashboard.png` using `plt.subplots(2, 2)`:
- Temperature vs. units sold (scatter, by category)
- Revenue distribution (histogram)
- Average units sold by store (bar)
- Units sold vs. revenue (scatter, by category)

This gives the client one image that summarizes the key relationships
in their sales data at a glance.

## Files Submitted
- `visualization_script.py`
- `client_project_dashboard.py`
- `retail_sales_data.csv` (input data)
- `plots/` (7 individual plots)
- `dashboard.png` (combined dashboard)
- `summary_week4.md` (this file)
