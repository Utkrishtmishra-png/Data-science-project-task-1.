"""
Week 4 - Hands-On Exercise: Data Visualization with Matplotlib and Seaborn
Concepts practiced: Matplotlib basic plots (line, bar, histogram, scatter)
and Seaborn advanced plots (heatmap, pairplot).

Uses the client's retail_sales_data.csv (cleaned of duplicates/NaNs first).
All plots are saved into the plots/ folder.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

INPUT_FILE = "retail_sales_data.csv"
PLOTS_DIR = "plots"

sns.set_theme(style="whitegrid")


def load_clean_data():
    df = pd.read_csv(INPUT_FILE)
    df = df.drop_duplicates().dropna(subset=["units_sold", "revenue"])
    df["date"] = pd.to_datetime(df["date"])
    return df


def plot_line_daily_revenue(df):
    """Matplotlib: basic line plot of total daily revenue over time."""
    daily = df.groupby("date")["revenue"].sum()

    plt.figure(figsize=(10, 5))
    plt.plot(daily.index, daily.values, color="steelblue")
    plt.title("Total Daily Revenue (All Stores)")
    plt.xlabel("Date")
    plt.ylabel("Revenue ($)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/01_line_daily_revenue.png", dpi=120)
    plt.close()


def plot_bar_revenue_by_category(df):
    """Matplotlib: basic bar chart of total revenue by category."""
    by_cat = df.groupby("category")["revenue"].sum().sort_values(ascending=False)

    plt.figure(figsize=(8, 5))
    plt.bar(by_cat.index, by_cat.values, color="darkorange")
    plt.title("Total Revenue by Product Category")
    plt.xlabel("Category")
    plt.ylabel("Total Revenue ($)")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/02_bar_revenue_by_category.png", dpi=120)
    plt.close()


def plot_histogram_units_sold(df):
    """Matplotlib: histogram showing the distribution of units sold."""
    plt.figure(figsize=(8, 5))
    plt.hist(df["units_sold"], bins=30, color="seagreen", edgecolor="white")
    plt.title("Distribution of Units Sold (per store/category/day)")
    plt.xlabel("Units Sold")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/03_histogram_units_sold.png", dpi=120)
    plt.close()


def plot_scatter_temp_vs_units(df):
    """Matplotlib: scatter plot of temperature vs. units sold, colored by category."""
    plt.figure(figsize=(9, 6))
    categories = df["category"].unique()
    for cat in categories:
        subset = df[df["category"] == cat]
        plt.scatter(subset["temperature_c"], subset["units_sold"], label=cat, alpha=0.5, s=15)
    plt.title("Temperature vs. Units Sold, by Category")
    plt.xlabel("Temperature (°C)")
    plt.ylabel("Units Sold")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/04_scatter_temp_vs_units.png", dpi=120)
    plt.close()


def plot_seaborn_heatmap(df):
    """Seaborn: correlation heatmap across numeric features."""
    numeric_cols = df[["units_sold", "revenue", "temperature_c"]]
    corr = numeric_cols.corr()

    plt.figure(figsize=(6, 5))
    sns.heatmap(corr, annot=True, cmap="coolwarm", vmin=-1, vmax=1, fmt=".2f")
    plt.title("Correlation Heatmap: Units Sold, Revenue, Temperature")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/05_seaborn_heatmap.png", dpi=120)
    plt.close()


def plot_seaborn_pairplot(df):
    """Seaborn: pairplot to visualize relationships across numeric features by category."""
    sample = df[["units_sold", "revenue", "temperature_c", "category"]]
    # Sample down for a readable pairplot (pairplot gets slow/dense on 1700+ rows)
    sample = sample.sample(n=min(400, len(sample)), random_state=1)

    g = sns.pairplot(sample, hue="category", diag_kind="kde", plot_kws={"alpha": 0.6, "s": 20})
    g.fig.suptitle("Pairwise Relationships by Category", y=1.02)
    g.savefig(f"{PLOTS_DIR}/06_seaborn_pairplot.png", dpi=120)
    plt.close("all")


def plot_seaborn_boxplot(df):
    """Seaborn: boxplot comparing revenue distributions across stores."""
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=df, x="store", y="revenue")
    plt.title("Revenue Distribution by Store")
    plt.xlabel("Store")
    plt.ylabel("Revenue ($)")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/07_seaborn_boxplot.png", dpi=120)
    plt.close()


def main():
    os.makedirs(PLOTS_DIR, exist_ok=True)
    df = load_clean_data()

    plot_line_daily_revenue(df)
    plot_bar_revenue_by_category(df)
    plot_histogram_units_sold(df)
    plot_scatter_temp_vs_units(df)
    plot_seaborn_heatmap(df)
    plot_seaborn_pairplot(df)
    plot_seaborn_boxplot(df)

    print(f"Saved 7 plots to '{PLOTS_DIR}/':")
    for fname in sorted(os.listdir(PLOTS_DIR)):
        print(f"  - {fname}")


if __name__ == "__main__":
    main()
