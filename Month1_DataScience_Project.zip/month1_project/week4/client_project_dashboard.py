"""
Week 4 - Client Project: Sales Analysis Dashboard
----------------------------------------------------
The client wants a single-image "dashboard" showing how temperature,
category, and store relate to units sold and revenue — combining
scatter plots and histograms as requested, built with Matplotlib
subplots and Seaborn styling.

Output: dashboard.png (a 2x2 grid of panels)
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

INPUT_FILE = "retail_sales_data.csv"
OUTPUT_FILE = "dashboard.png"

sns.set_theme(style="whitegrid")


def load_clean_data():
    df = pd.read_csv(INPUT_FILE)
    df = df.drop_duplicates().dropna(subset=["units_sold", "revenue"])
    df["date"] = pd.to_datetime(df["date"])
    return df


def build_dashboard(df):
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle("Retail Sales Dashboard — Feature Relationships", fontsize=16, y=0.98)

    # Panel 1 (top-left): scatter — temperature vs units sold, colored by category
    ax = axes[0, 0]
    for cat in df["category"].unique():
        subset = df[df["category"] == cat]
        ax.scatter(subset["temperature_c"], subset["units_sold"], label=cat, alpha=0.4, s=12)
    ax.set_title("Temperature vs. Units Sold (by Category)")
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Units Sold")
    ax.legend(fontsize=8, loc="upper left")

    # Panel 2 (top-right): histogram — revenue distribution
    ax = axes[0, 1]
    ax.hist(df["revenue"], bins=30, color="mediumpurple", edgecolor="white")
    ax.set_title("Distribution of Daily Revenue (per store/category)")
    ax.set_xlabel("Revenue ($)")
    ax.set_ylabel("Frequency")

    # Panel 3 (bottom-left): bar — average units sold by store
    ax = axes[1, 0]
    store_avg = df.groupby("store")["units_sold"].mean().sort_values(ascending=False)
    ax.bar(store_avg.index, store_avg.values, color="teal")
    ax.set_title("Average Units Sold by Store")
    ax.set_xlabel("Store")
    ax.set_ylabel("Avg. Units Sold")
    ax.tick_params(axis="x", rotation=20)

    # Panel 4 (bottom-right): scatter — units sold vs revenue, colored by category
    ax = axes[1, 1]
    for cat in df["category"].unique():
        subset = df[df["category"] == cat]
        ax.scatter(subset["units_sold"], subset["revenue"], label=cat, alpha=0.4, s=12)
    ax.set_title("Units Sold vs. Revenue (by Category)")
    ax.set_xlabel("Units Sold")
    ax.set_ylabel("Revenue ($)")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(OUTPUT_FILE, dpi=130)
    plt.close()


def main():
    df = load_clean_data()
    build_dashboard(df)
    print(f"Dashboard saved to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
